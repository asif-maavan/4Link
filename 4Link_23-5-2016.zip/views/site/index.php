<?php

//use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Products */

$this->title = '4Link';
?>
<div class="">
    <div class="padtop44">
        <img class="" src="<?php echo Yii::$app->request->baseUrl; ?>/images/logo.png" alt="Chania" >
    </div>
    <div class="padtop44">
        <p><?php echo $message; ?></p>
    </div>
</div>